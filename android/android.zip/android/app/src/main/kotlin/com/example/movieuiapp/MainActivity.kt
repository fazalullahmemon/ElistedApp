package com.example.Elistadapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
